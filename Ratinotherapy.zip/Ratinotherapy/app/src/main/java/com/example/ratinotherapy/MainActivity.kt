import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.ratinotherapy.R

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myWebView = findViewById<WebView>(R.id.webview)
        myWebView?.let {
            val webSettings = it.settings
            webSettings.javaScriptEnabled = true
            it.webViewClient = WebViewClient()
            it.loadUrl("http://192.168.10.120:5000/")
        }
    }
}

///http://127.0.0.1:5000/
















